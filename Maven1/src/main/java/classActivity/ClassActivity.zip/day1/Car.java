package classActivity.day1;

public class Car {
		String CarName;
		int CarNumber;
		float Capacity;
		boolean IsPunctured;
	
		public int maxSpeed() {
			return 180;
		}
		
		public double airPressure() {
			return 150.87914;
		}
		
		public boolean isEngineOn() {
			return false;
		}
	
}
