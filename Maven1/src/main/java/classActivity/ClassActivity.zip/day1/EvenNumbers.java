package classActivity.day1;

public class EvenNumbers {

	public static void main(String[] args) {
		int x=80;
		System.out.println("Even numbers between 80 and 60 are:");
		for (;x>=60;x--) {
			if(x%2==0)
				System.out.println(x);
		}

	}

}
