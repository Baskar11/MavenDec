package classActivity.day1;

public class Prime {

	public static void main(String[] args) {
		System.out.println("Prime numbers between 1 and 100:");
		for (int i=1;i<=100;i++) {
			
		}
		}
	
}
