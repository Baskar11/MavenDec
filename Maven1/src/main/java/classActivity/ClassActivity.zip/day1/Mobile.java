package classActivity.day1;

public class Mobile {

	int year=2018;
	String model="Redmi";
	boolean active = true;
	public int YearOfLaunch() {
		return year;
	}
	
	public String ModelName() {
		return model;
	}

	public boolean IsActive() {
		return active;
	}
	public void MobColor() {
	System.out.println("Mobile color is Blue");
	}
}
