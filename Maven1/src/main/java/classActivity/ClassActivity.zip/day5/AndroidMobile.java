package classActivity.day5;

public class AndroidMobile extends SmartMobile {
	public void androidPlayStore() {
		System.out.println("Find all your apps here");
	}
	
	public void makeCall() {
		System.out.println("Video call activated");
	}

}
