package classActivity.day5;
public class BasicMobile {
	public void sendMessage() {
		System.out.println("Messaging App invoked");
	}
	
	void makeCall() {
		System.out.println("Call has been made");
	}
	
	public void receiveCall() {
		System.out.println("Call is in progress");
	}

}