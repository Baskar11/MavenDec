package classActivity.day5;

public interface Cibil {

	public void getCreditLimit();
}

