package classActivity.day5;

public interface RBI {
	
public void maxTrax();
public void minBal();
public void verifyAadhar();

}
