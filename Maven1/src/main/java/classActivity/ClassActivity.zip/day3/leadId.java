package classActivity.day3;

public class leadId {

	public static void main(String[] args) {
		String lead = "TestLeaf (10002)";
		String[] id = lead.split(" ");
		System.out.println(id[1]);
	}

}
